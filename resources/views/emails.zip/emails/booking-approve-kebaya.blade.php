Selamat, {{ $first_name }} {{ $last_name}}!
<br>
<br>
Pesanan Anda masih tersedia.
<br>
Silahkan melanjutkan pesanan Anda melalui link dibawah ini:
<br>

{{ url('booking/approved/busana', $link)}}