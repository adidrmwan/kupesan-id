Dear, {{ $first_name }} {{ $last_name}}!
<br>
<br>
Pesanan “{{$category_name}}” Anda
<br>
Kode Booking : <b class="text-uppercase">{{$kode_booking}}</b>
<table class="table table-bordered">
	<tr>
		<th style="text-align: left;">Name Partner : {{$partner_name}}</th>
	</tr>
	<tr>
		<th style="text-align: left;">Tanggal Sewa  : {{ date('d F Y', strtotime($start_date)) }} - {{ date('d F Y', strtotime($end_date)) }}</th>
	</tr>
	<tr>
		<th style="text-align: left;">Name Paket : <span style="text-transform: uppercase;">{{$name}}</span></th>
	</tr>
	<tr>
		<th style="text-align: left;">Tipe / Set Paket : <span style="text-transform: uppercase;">{{$category_name}} / {{$set}}</span></th>
	</tr>
	<tr>
		<th style="text-align: left;">Ukuran : <span style="text-transform: uppercase;">{{$size}}</span></th>
	</tr>
	<tr>
		<th style="text-align: left;">Kuantitas Paket : <span style="text-transform: uppercase;">{{$kuantitas_pesanan}}</span></th>
	</tr>
	<tr>
		<th style="text-align: left;">Harga Paket : Rp {{number_format($booking_price,0,',','.')}}</th>
	</tr>
	<tr>
		<th style="text-align: left;">Deposit : Rp {{number_format($deposit,0,',','.')}}</th>
	</tr>
	@if($biaya_dry_clean != '0')
	<tr>
		<th style="text-align: left;">Dry Clean Cost : Rp {{number_format($biaya_dry_clean,0,',','.')}}</th>
	</tr>
	@endif
	@if($biaya_kirim != '0')
	<tr>
		<th style="text-align: left;">Biaya Kirim : Rp {{number_format($biaya_kirim,0,',','.')}}</th>
	</tr>
	@endif
	<tr>
		<th style="text-align: left;">Total : Rp {{number_format($booking_total,0,',','.')}}</th>
	</tr>
</table>
<br>

Mohon tunjukkan Booking Code untuk menikmati pesanan Anda. Have a nice day!  

-Kupesan.ID 
{{ url('home')}}