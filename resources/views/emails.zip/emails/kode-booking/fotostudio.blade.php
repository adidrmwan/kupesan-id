Dear, {{ $first_name }} {{ $last_name}}!
<br>
<br>
Pesanan “Spot Foto” Anda
<br>
Kode Booking : <b>{{$kode_booking}}</b>
<table class="table table-bordered">
	<tr>
		<th style="text-align: left;">Nama Partner : {{$partner_name}}</th>
	</tr>
	<tr>
		<th style="text-align: left;">Tanggal Sewa : {{ date('d F Y', strtotime($booking_start_date)) }} - {{ date('d F Y', strtotime($booking_end_date)) }}</th>
	</tr>
	<tr>
		<th style="text-align: left;">Nama Paket : <span style="text-transform: uppercase;">{{$pkg_name_them}}</span></th>
	</tr>
	<tr>
		<th style="text-align: left;">Harga Paket : Rp {{number_format($booking_normal_price,0,',','.')}}</th>
	</tr>
	<tr>
		<th style="text-align: left;">Harga Overtime : Rp {{number_format($booking_overtime_price,0,',','.')}}</th>
	</tr>
	<tr>
		<th style="text-align: left;">Total : Rp {{number_format($booking_total,0,',','.')}}</th>
	</tr>
</table>
<br>
Mohon tunjukkan Booking Code untuk menikmati pesanan Anda. Have a nice day!  

-Kupesan.ID 
{{ url('home')}}