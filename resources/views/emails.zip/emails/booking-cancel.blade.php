Maaf, {{ $first_name }} {{ $last_name}}.
<br>
<br>
Pesanan Anda tidak tersedia.
<br>
Silahkan melakukan pemesanan kembali di Kupesan.id atau menghubungi customer service untuk info lebih lanjut.
<br>
{{ url('home')}}