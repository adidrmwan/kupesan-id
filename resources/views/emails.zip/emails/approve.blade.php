Selamat, Partner-KU!
<br>
<br>
Profil perusahaan Anda telah berhasil ditinjau oleh tim kami.
<br>
Untuk mengaktifkan akun Anda. Silahkan log-in melalui link dibawah ini:
<br>

{{ url('partner/activation', $link)}}