Maaf, {{ $first_name }} {{ $last_name}}.
<br>
<br>
Bukti Pembayaran Anda ditolak.
<br>
Silahkan melakukan pemesanan kembali di Kupesan.id atau menghubungi customer serveice untuk info lebih lanjut.
<br>
{{ url('home')}}