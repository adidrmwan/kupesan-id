Halo, {{$partner_name}}.
<br>
<br>
Berikut adalah detail pesanan dari pelanggan Kupesan,
<br>
Name Pelanggan : {{$user_name}}<br>
Tanggal Sewa: {{ date('d F Y', strtotime($start_date)) }} - {{ date('d F Y', strtotime($end_date)) }}<br>
Name Paket : <span style="text-transform: uppercase;">{{$name}}</span><br>
Ukuran : <span style="text-transform: uppercase;">{{$size}}</span><br>
Total : Rp {{number_format($booking_total,0,',','.')}}

Apakah anda akan menerima pesanan ini?<br>

{{ url('partner/dashboard/busana', $link)}}