Selamat, Partner-Ku!.
<br>
<br>
Anda memiliki pesanan baru!!
<br>
<br>
Berikut adalah detail pesanan dari pelanggan Kupesan:
<br>
<span style="text-transform: uppercase;">[ Paket - {{$pkg_name_them}} ]</span><br>
Nama Pelanggan : {{$booking_user_name}}<br>
Jadwal Pesan : {{ date('d F Y', strtotime($booking_start_date)) }}, {{$booking_start_time}}:00 - {{$booking_end_time + $booking_overtime}}:00 WIB<br>
Total : Rp {{number_format($booking_total,0,',','.')}}<br>
<br>
Anda dapat menyetujui pesanan melalui link dibawah ini :<br>

{{ url('partner/dashboard', $link)}}